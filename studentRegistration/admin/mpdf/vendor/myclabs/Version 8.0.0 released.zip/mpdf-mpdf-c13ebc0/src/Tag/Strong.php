<?php

namespace Mpdf\Tag;

class Strong extends InlineTag
{


}
